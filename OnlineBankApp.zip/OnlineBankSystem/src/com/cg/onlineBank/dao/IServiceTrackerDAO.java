package com.cg.onlineBank.dao;

import java.util.ArrayList;

import com.cg.onlineBank.dto.BankCustomerBean;
import com.cg.onlineBank.dto.ServiceTrackerBean;

public interface IServiceTrackerDAO {
	
	public ArrayList<ServiceTrackerBean> fetchServiceDetailsByID(int serviceID);
	public ArrayList<ServiceTrackerBean> fetchServiceDetailsByAccountID(int accountID);
	public ArrayList<ServiceTrackerBean> statusOfAllRequest();
	public ArrayList<ServiceTrackerBean> fetchServiceRequestID(int accountID);
	public ArrayList<ServiceTrackerBean> getRequestHistory();
	public ArrayList<BankCustomerBean> getAccountNumber(String pan);
	
	public int transferFund(int transferAccount, int transferAmount);
	public int registerPayee(int accountID, int payeeAccountID, String payeeAccountName);
	
}
