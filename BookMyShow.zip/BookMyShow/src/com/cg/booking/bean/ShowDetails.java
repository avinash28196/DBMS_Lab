package com.cg.booking.bean;

public class ShowDetails {
	
	private String showName;
	private String location;
	private String date;
	private int price;
	private int avilableSeats;
	
	public ShowDetails(){
		
	}

	public ShowDetails(String showName, String location, String date, int price, int avilableSeats) {
		super();
		this.showName = showName;
		this.location = location;
		this.date = date;
		this.price = price;
		this.avilableSeats = avilableSeats;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getAvilableSeats() {
		return avilableSeats;
	}

	public void setAvilableSeats(int avilableSeats) {
		this.avilableSeats = avilableSeats;
	}

	@Override
	public String toString() {
		return "ShowDetails [showName=" + showName + ", location=" + location + ", date=" + date + ", price=" + price
				+ ", avilableSeats=" + avilableSeats + "]";
	}
	
	
	

}
