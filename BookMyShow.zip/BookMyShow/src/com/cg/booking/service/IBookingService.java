package com.cg.booking.service;

import java.util.ArrayList;

import com.cg.booking.bean.ShowDetails;
import com.cg.booking.exception.BookingException;

public interface IBookingService {
	
	ArrayList<ShowDetails> getShowDetails() throws BookingException;

}
