package com.cg.booking.service;

import java.util.ArrayList;

import com.cg.booking.bean.ShowDetails;
import com.cg.booking.dao.BookingDaoIMpl;
import com.cg.booking.dao.IBookingDAO;
import com.cg.booking.exception.BookingException;

public class BookingServiceImpl implements IBookingService{
	IBookingDAO dao = new BookingDaoIMpl();
	
	@Override
	public ArrayList<ShowDetails> getShowDetails() throws BookingException {
		
		return dao.getShowDetails();
	}

}
