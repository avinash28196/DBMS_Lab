package com.cg.booking.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.booking.bean.ShowDetails;
import com.cg.booking.exception.BookingException;
import com.cg.booking.service.BookingServiceImpl;
import com.cg.booking.service.IBookingService;


@WebServlet("*.obj")
public class BookingControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String targetPath;
	IBookingService service = new BookingServiceImpl();
	ShowDetails bean = new ShowDetails();
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String ServletPath=request.getServletPath();
		
		switch(ServletPath)
		{
		case "/showDetails.obj":
			ArrayList<Integer> list=new ArrayList<Integer>();
			try {
				String movieName = request.getParameter("movieName");
				String location = request.getParameter("location");
				String date = request.getParameter("date");
				String price = request.getParameter("price");
				String seatAvailablity = request.getParameter("seat");
				
				
			}
			
			catch (BookingException e) {
				session.setAttribute("error", e.getMessage());
				targetPath="error.jsp";		
				}
			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetPath);
		rd.forward(request, response);
	}

}
