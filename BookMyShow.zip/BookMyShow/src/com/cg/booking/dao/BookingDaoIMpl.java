package com.cg.booking.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.cg.booking.bean.ShowDetails;
import com.cg.booking.dbutil.DBUtil;
import com.cg.booking.exception.BookingException;

public class BookingDaoIMpl implements IBookingDAO{
	Connection conn = null;
	@Override
	public ArrayList<ShowDetails> getShowDetails() throws BookingException {
		ArrayList<ShowDetails> list =new ArrayList<ShowDetails>();
		try {
			conn=DBUtil.getConnection();
			String sql="select trainee_id from trainees";
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next())
			{
				ShowDetails shows = new ShowDetails();
				shows.setShowName(rs.getString(1));
				shows.setLocation(rs.getString(2));
				shows.setDate(rs.getString(3));
				shows.setPrice(rs.getInt(4));
				shows.setAvilableSeats(rs.getInt(5));
				
			
				list.add(shows);
			}
			
			}
			catch (SQLException e) {
				throw new BookingException(e.getMessage());
			}
		
		return list;
		
	
	}

}
