package com.cg.booking.dao;

import java.util.ArrayList;

import com.cg.booking.bean.ShowDetails;
import com.cg.booking.exception.BookingException;

public interface IBookingDAO {

	ArrayList<ShowDetails> getShowDetails() throws BookingException;

}
